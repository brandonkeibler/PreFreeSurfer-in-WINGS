#!/bin/bash

replicate1=$1
replicate2=$2

cat replicate1
