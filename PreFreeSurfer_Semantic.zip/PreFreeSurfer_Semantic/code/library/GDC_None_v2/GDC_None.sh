#!/bin/bash

inputs=$1
outputs=$2

counter=0
for input in "${inputs[@]}" 
do
	cat $input > ${outputs[counter]}
	((counter++))
done
