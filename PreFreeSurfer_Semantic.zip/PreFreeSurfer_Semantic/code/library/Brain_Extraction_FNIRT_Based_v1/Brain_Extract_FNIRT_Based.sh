#!/bin/bash

fullImage=$1
template=$2
templateMask=$3
template2mm=$4
template2mmMask=$5
FNIRT_config=$6

brainImage=$7
brainImageMask=$8

bash BrainExtraction_FNIRTbased.sh \
        --in=${fullImage} \
        --ref=${template} \
        --refmask=${templateMask} \
        --ref2mm=${template2mm} \
        --ref2mmmask=${template2mmMask} \
        --outbrain=${brainImage} \
    	--outbrainmask=${brainImageMask} \
    	--fnirtconfig=${FNIRT_config}
