#!/bin/bash

unaligned=$1
template=$2
brainSize=$3
aligned=$4
transformations=$5

bash ACPCAlignment.sh \
        --in=$unaligned \
        --ref=$template \
        --out=$unaligned_acpc \
        --omat=$transformations \
        --brainsize=$brainSize
